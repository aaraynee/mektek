<nav id="mp-menu" class="mp-menu">
	<ul>
		<%= content %>
	</ul>
</nav>
